import React, { useState, useEffect } from 'react';
import { 
  signInWithPopup, 
  signInWithPhoneNumber, 
  RecaptchaVerifier, 
  ConfirmationResult 
} from 'firebase/auth';
import { auth, googleProvider, facebookProvider } from '@/src/lib/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogTrigger 
} from '@/components/ui/dialog';
import { LogIn, Phone, Facebook, Chrome, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LoginModalProps {
  language: 'en' | 'ar' | 'ml';
}

export const LoginModal: React.FC<LoginModalProps> = ({ language }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'options' | 'phone' | 'code'>('options');

  useEffect(() => {
    if (step === 'phone') {
      window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible',
      });
    }
  }, [step]);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error("Google Login Error:", err);
      if (err.code === 'auth/network-request-failed') {
        setError(language === 'ar' ? 'خطأ في الشبكة. يرجى التأكد من السماح بنطاق التطبيق في وحدة تحكم Firebase.' : 
                 language === 'ml' ? 'നെറ്റ്‌വർക്ക് തകരാർ. Firebase കൺസോളിൽ ഡൊമെയ്ൻ അനുവദിച്ചിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.' : 
                 'Network error. Please ensure the app domain is allowlisted in the Firebase Console.');
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleFacebookLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, facebookProvider);
    } catch (err: any) {
      console.error("Facebook Login Error:", err);
      if (err.code === 'auth/network-request-failed') {
        setError(language === 'ar' ? 'خطأ في الشبكة. يرجى التأكد من السماح بنطاق التطبيق في وحدة تحكم Firebase.' : 
                 language === 'ml' ? 'നെറ്റ്‌വർക്ക് തകരാർ. Firebase കൺസോളിൽ ഡൊമെയ്ൻ അനുവദിച്ചിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.' : 
                 'Network error. Please ensure the app domain is allowlisted in the Firebase Console.');
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneSignIn = async () => {
    if (!phoneNumber) return;
    setLoading(true);
    setError(null);
    try {
      const appVerifier = window.recaptchaVerifier;
      const result = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
      setConfirmationResult(result);
      setStep('code');
    } catch (err: any) {
      setError(err.message);
      setStep('phone');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!verificationCode || !confirmationResult) return;
    setLoading(true);
    setError(null);
    try {
      await confirmationResult.confirm(verificationCode);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const t = {
    en: {
      login: 'Login',
      title: 'Join Muslim',
      desc: 'Connect with the global Ummah and access personalized Fiqh resources.',
      google: 'Continue with Google',
      facebook: 'Continue with Facebook',
      phone: 'Continue with Phone',
      phonePlaceholder: '+1 234 567 890',
      codePlaceholder: '6-digit code',
      sendCode: 'Send Code',
      verify: 'Verify Code',
      back: 'Back'
    },
    ar: {
      login: 'تسجيل الدخول',
      title: 'انضم إلى مسلم',
      desc: 'تواصل مع الأمة العالمية واحصل على موارد فقهية مخصصة.',
      google: 'المتابعة باستخدام جوجل',
      facebook: 'المتابعة باستخدام فيسبوك',
      phone: 'المتابعة باستخدام الهاتف',
      phonePlaceholder: '+966 50 000 0000',
      codePlaceholder: 'رمز من 6 أرقام',
      sendCode: 'إرسال الرمز',
      verify: 'تحقق من الرمز',
      back: 'رجوع'
    },
    ml: {
      login: 'ലോഗിൻ',
      title: 'മുസ്ലിമിൽ ചേരുക',
      desc: 'ആഗോള ഉമ്മയുമായി ബന്ധപ്പെടുകയും വ്യക്തിഗതമാക്കിയ ഫിഖ്ഹ് വിഭവങ്ങൾ ആക്സസ് ചെയ്യുകയും ചെയ്യുക.',
      google: 'Google ഉപയോഗിച്ച് തുടരുക',
      facebook: 'Facebook ഉപയോഗിച്ച് തുടരുക',
      phone: 'ഫോൺ ഉപയോഗിച്ച് തുടരുക',
      phonePlaceholder: '+91 98765 43210',
      codePlaceholder: '6 അക്ക കോഡ്',
      sendCode: 'കോഡ് അയയ്ക്കുക',
      verify: 'കോഡ് പരിശോധിക്കുക',
      back: 'തിരികെ'
    }
  }[language];

  return (
    <Dialog onOpenChange={() => { setStep('options'); setError(null); }}>
      <DialogTrigger render={<Button variant="outline" className="border-primary/20 hover:bg-primary/5 gap-2" />}>
          <LogIn className="w-4 h-4" />
          {t.login}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[400px] bg-card/95 backdrop-blur-xl border-primary/10">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif text-center">{t.title}</DialogTitle>
          <DialogDescription className="text-center">{t.desc}</DialogDescription>
        </DialogHeader>

        <div className="py-6 space-y-4">
          <AnimatePresence mode="wait">
            {step === 'options' && (
              <motion.div 
                key="options"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-3"
              >
                <Button 
                  onClick={handleGoogleLogin} 
                  variant="outline" 
                  className="w-full h-12 gap-3 border-primary/10 hover:bg-primary/5"
                  disabled={loading}
                >
                  <Chrome className="w-5 h-5 text-blue-500" />
                  {t.google}
                </Button>
                <Button 
                  onClick={handleFacebookLogin} 
                  variant="outline" 
                  className="w-full h-12 gap-3 border-primary/10 hover:bg-primary/5"
                  disabled={loading}
                >
                  <Facebook className="w-5 h-5 text-blue-600" />
                  {t.facebook}
                </Button>
                <Button 
                  onClick={() => setStep('phone')} 
                  variant="outline" 
                  className="w-full h-12 gap-3 border-primary/10 hover:bg-primary/5"
                  disabled={loading}
                >
                  <Phone className="w-5 h-5 text-secondary" />
                  {t.phone}
                </Button>
              </motion.div>
            )}

            {step === 'phone' && (
              <motion.div 
                key="phone"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Input 
                    placeholder={t.phonePlaceholder}
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="h-12 bg-background/50"
                  />
                  <div id="recaptcha-container"></div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={() => setStep('options')} className="flex-1">{t.back}</Button>
                  <Button onClick={handlePhoneSignIn} className="flex-[2] bg-primary" disabled={loading || !phoneNumber}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : t.sendCode}
                  </Button>
                </div>
              </motion.div>
            )}

            {step === 'code' && (
              <motion.div 
                key="code"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <Input 
                  placeholder={t.codePlaceholder}
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  className="h-12 text-center text-2xl tracking-[0.5em] bg-background/50"
                  maxLength={6}
                />
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={() => setStep('phone')} className="flex-1">{t.back}</Button>
                  <Button onClick={handleVerifyCode} className="flex-[2] bg-primary" disabled={loading || verificationCode.length !== 6}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : t.verify}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {error && (
            <div className="space-y-2">
              <p className="text-xs text-destructive text-center mt-2">{error}</p>
              {error.includes('allowlisted') && (
                <div className="p-3 bg-destructive/10 rounded-lg text-[10px] text-destructive space-y-1">
                  <p className="font-bold">Troubleshooting:</p>
                  <p>1. Go to Firebase Console &gt; Auth &gt; Settings &gt; Authorized Domains</p>
                  <p>2. Add these domains:</p>
                  <code className="block bg-background/50 p-1 rounded mt-1 break-all">
                    {window.location.hostname}
                  </code>
                  <p>3. Disable Ad-blockers if the error persists.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

declare global {
  interface Window {
    recaptchaVerifier: any;
  }
}
