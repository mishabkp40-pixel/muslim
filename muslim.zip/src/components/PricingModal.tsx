import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Star, Zap, Shield, Crown, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { loadStripe } from '@stripe/stripe-js';
import { useAuth } from '@/src/components/AuthProvider';

interface PricingModalProps {
  language: 'en' | 'ar' | 'ml';
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({ language, open, onOpenChange }) => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpgrade = async () => {
    if (!user) {
      setError(language === 'ar' ? 'يرجى تسجيل الدخول أولاً' : language === 'ml' ? 'ആദ്യം ലോഗിൻ ചെയ്യുക' : 'Please login first');
      return;
    }

    const publishableKey = (import.meta as any).env.VITE_STRIPE_PUBLISHABLE_KEY;
    
    // Validate Publishable Key format
    if (!publishableKey || !publishableKey.startsWith('pk_')) {
      setError(
        language === 'ar' 
          ? 'مفتاح Stripe Publishable غير صالح. يرجى إعداد مفتاح يبدأ بـ pk_ في الإعدادات.' 
          : language === 'ml' 
          ? 'അസാധുവായ Stripe Publishable Key. pk_ എന്ന് തുടങ്ങുന്ന കീ സെറ്റിംഗ്‌സിൽ നൽകുക.' 
          : 'Invalid Stripe Publishable Key. Please provide a key starting with "pk_" in the Settings menu.'
      );
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.uid,
          email: user.email,
        }),
      });

      const session = await response.json();
      if (session.error) {
        if (session.error.includes('Invalid API Key')) {
          throw new Error('The Stripe Secret Key provided in the backend is invalid. It should start with "sk_".');
        }
        throw new Error(session.error);
      }

      const stripe = await loadStripe(publishableKey);
      if (stripe) {
        const { error: stripeError } = await (stripe as any).redirectToCheckout({
          sessionId: session.id,
        });
        if (stripeError) throw stripeError;
      }
    } catch (error: any) {
      console.error('Upgrade error:', error);
      setError(error.message || 'Failed to initiate checkout.');
    } finally {
      setIsLoading(false);
    }
  };

  const [isSuccess, setIsSuccess] = useState(false);

  const handleDemoUpgrade = async () => {
    if (!user) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/demo-upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.uid }),
      });
      const data = await response.json();
      if (data.status === 'success') {
        setIsSuccess(true);
        setTimeout(() => {
          if (onOpenChange) onOpenChange(false);
          setIsSuccess(false);
        }, 1500);
      } else {
        throw new Error(data.error);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const content = {
    en: {
      trigger: 'Upgrade to Pro',
      title: 'Choose Your Plan',
      desc: 'Unlock the full potential of Muslim with Pro features.',
      free: 'Free',
      pro: 'Pro',
      price: '₹20',
      period: '/month',
      current: 'Current Plan',
      upgrade: 'Upgrade Now',
      features: [
        'Unlimited AI Scholar Questions',
        'Exclusive Classical Text Access',
        'Advanced Zakat Reports',
        'Priority Support',
        'Ad-Free Experience'
      ]
    },
    ar: {
      trigger: 'ترقية إلى برو',
      title: 'اختر خطتك',
      desc: 'أطلق العنان للإمكانيات الكاملة لـ "مسلم" مع ميزات برو.',
      free: 'مجاني',
      pro: 'برو',
      price: '٢٠ روبية',
      period: '/شهر',
      current: 'الخطة الحالية',
      upgrade: 'ترقية الآن',
      features: [
        'أسئلة غير محدودة للعالم الآلي',
        'وصول حصري للنصوص الكلاسيكية',
        'تقارير زكاة متقدمة',
        'دعم ذو أولوية',
        'تجربة خالية من الإعلانات'
      ]
    },
    ml: {
      trigger: 'പ്രോയിലേക്ക് മാറുക',
      title: 'നിങ്ങളുടെ പ്ലാൻ തിരഞ്ഞെടുക്കുക',
      desc: 'പ്രോ ഫീച്ചറുകൾ ഉപയോഗിച്ച് മുസ്ലീം ആപ്പിന്റെ പൂർണ്ണ സാധ്യതകൾ പ്രയോജനപ്പെടുത്തുക.',
      free: 'സൗജന്യം',
      pro: 'പ്രോ',
      price: '₹20',
      period: '/മാസം',
      current: 'നിലവിലെ പ്ലാൻ',
      upgrade: 'ഇപ്പോൾ അപ്‌ഗ്രേഡ് ചെയ്യുക',
      features: [
        'പരിധിയില്ലാത്ത AI സ്കോളർ ചോദ്യങ്ങൾ',
        'ക്ലാസിക്കൽ ഗ്രന്ഥങ്ങളിലേക്കുള്ള പ്രത്യേക പ്രവേശനം',
        'വിപുലമായ സകാത്ത് റിപ്പോർട്ടുകൾ',
        'മുൻഗണനാ പിന്തുണ',
        'പരസ്യരഹിത അനുഭവം'
      ]
    }
  };

  const t = content[language];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger render={<Button variant="outline" className="border-secondary text-secondary hover:bg-secondary/10 rounded-full px-6 flex items-center gap-2 group" />}>
        <Crown className="w-4 h-4 transition-transform group-hover:rotate-12" />
        <span>{t.trigger}</span>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-background border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-3xl font-serif text-primary text-center">{t.title}</DialogTitle>
          <DialogDescription className="text-center text-muted-foreground">
            {t.desc}
          </DialogDescription>
        </DialogHeader>
        
        {error && (
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-xl text-destructive text-xs space-y-2">
            <p className="text-center font-medium">{error}</p>
            <p className="text-center opacity-80">
              You can find your API keys in the{' '}
              <a 
                href="https://dashboard.stripe.com/test/apikeys" 
                target="_blank" 
                rel="noopener noreferrer"
                className="underline font-bold hover:opacity-100"
              >
                Stripe Dashboard
              </a>.
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleDemoUpgrade}
              disabled={isLoading || isSuccess}
              className={`w-full border-destructive/30 text-destructive hover:bg-destructive/5 mt-2 ${isSuccess ? 'bg-green-500/10 border-green-500 text-green-600' : ''}`}
            >
              {isSuccess ? 'Pro Activated! • تم التفعيل!' : 'Try Pro for Free (Demo Mode)'}
            </Button>
          </div>
        )}
        <div className="grid grid-cols-1 gap-6 mt-6">
          <Card className="border-primary/10 bg-muted/30 relative overflow-hidden">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl font-serif">{t.free}</CardTitle>
                <Badge variant="secondary">$0</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <Button variant="ghost" disabled className="w-full rounded-full">{t.current}</Button>
            </CardContent>
          </Card>

          <Card className="border-secondary bg-secondary/5 relative overflow-hidden ring-2 ring-secondary/20">
            <div className="absolute top-0 right-0 bg-secondary text-secondary-foreground text-[10px] font-bold px-3 py-1 rounded-bl-lg uppercase tracking-widest">
              Recommended
            </div>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl font-serif flex items-center gap-2">
                  <Crown className="w-5 h-5 text-secondary" />
                  {t.pro}
                </CardTitle>
                <div className="text-right">
                  <span className="text-2xl font-bold text-secondary">{t.price}</span>
                  <span className="text-xs text-muted-foreground">{t.period}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <ul className="space-y-3">
                {t.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <div className="w-5 h-5 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 text-secondary" />
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button 
                onClick={handleUpgrade} 
                disabled={isLoading}
                className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold rounded-full h-12 shadow-lg shadow-secondary/20"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : t.upgrade}
              </Button>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
