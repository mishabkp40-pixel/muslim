import React, { useState } from 'react';
import { Calculator, Info, Coins, Wallet, Landmark } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ZakatCalculatorProps {
  language: 'en' | 'ar' | 'ml';
}

export const ZakatCalculator: React.FC<ZakatCalculatorProps> = ({ language }) => {
  const [cash, setCash] = useState<string>('');
  const [gold, setGold] = useState<string>('');
  const [silver, setSilver] = useState<string>('');
  const [other, setOther] = useState<string>('');
  const [result, setResult] = useState<number | null>(null);

  const calculate = () => {
    const total = (Number(cash) || 0) + (Number(gold) || 0) + (Number(silver) || 0) + (Number(other) || 0);
    setResult(total * 0.025);
  };

  const labels = {
    en: {
      title: 'Zakat Calculator',
      desc: 'Calculate your annual Zakat (2.5% of wealth)',
      cash: 'Cash & Savings',
      gold: 'Gold Value',
      silver: 'Silver Value',
      other: 'Other Assets',
      calc: 'Calculate',
      result: 'Your Zakat Amount:',
      nisab: 'Note: Zakat is only due if wealth exceeds Nisab threshold.'
    },
    ar: {
      title: 'حاسبة الزكاة',
      desc: 'احسب زكاتك السنوية (2.5% من الثروة)',
      cash: 'النقد والمدخرات',
      gold: 'قيمة الذهب',
      silver: 'قيمة الفضة',
      other: 'أصول أخرى',
      calc: 'احسب',
      result: 'مبلغ الزكاة المستحق:',
      nisab: 'ملاحظة: تجب الزكاة فقط إذا تجاوزت الثروة حد النصاب.'
    },
    ml: {
      title: 'സകാത്ത് കാൽക്കുലേറ്റർ',
      desc: 'നിങ്ങളുടെ വാർഷിക സകാത്ത് കണക്കാക്കുക (സമ്പത്തിന്റെ 2.5%)',
      cash: 'പണം & സമ്പാദ്യം',
      gold: 'സ്വർണ്ണത്തിന്റെ മൂല്യം',
      silver: 'വെള്ളിയുടെ മൂല്യം',
      other: 'മറ്റ് ആസ്തികൾ',
      calc: 'കണക്കാക്കുക',
      result: 'നിങ്ങളുടെ സകാത്ത് തുക:',
      nisab: 'ശ്രദ്ധിക്കുക: സമ്പത്ത് നിസാബ് പരിധി കവിഞ്ഞാൽ മാത്രമേ സകാത്ത് നിർബന്ധമാകൂ.'
    }
  };

  const t = labels[language];

  return (
    <Card className="h-full border-primary/10 bg-card/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-serif flex items-center gap-2">
          <Calculator className="w-5 h-5 text-secondary" />
          {t.title}
        </CardTitle>
        <CardDescription>{t.desc}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-medium flex items-center gap-2">
              <Wallet className="w-3 h-3 text-muted-foreground" />
              {t.cash}
            </label>
            <Input 
              type="number" 
              placeholder="0.00" 
              value={cash} 
              onChange={(e) => setCash(e.target.value)}
              className="bg-background/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-medium flex items-center gap-2">
                <Coins className="w-3 h-3 text-muted-foreground" />
                {t.gold}
              </label>
              <Input 
                type="number" 
                placeholder="0.00" 
                value={gold} 
                onChange={(e) => setGold(e.target.value)}
                className="bg-background/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium flex items-center gap-2">
                <Landmark className="w-3 h-3 text-muted-foreground" />
                {t.silver}
              </label>
              <Input 
                type="number" 
                placeholder="0.00" 
                value={silver} 
                onChange={(e) => setSilver(e.target.value)}
                className="bg-background/50"
              />
            </div>
          </div>
        </div>

        <Button 
          onClick={calculate} 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
        >
          {t.calc}
        </Button>

        {result !== null && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-secondary/10 border border-secondary/20 rounded-xl text-center"
          >
            <span className="text-xs text-muted-foreground block mb-1">{t.result}</span>
            <span className="text-2xl font-bold text-secondary">
              {result.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </motion.div>
        )}

        <div className="flex items-start gap-2 p-3 bg-muted/30 rounded-lg">
          <Info className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-[10px] text-muted-foreground leading-tight">
            {t.nisab}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

import { motion } from 'motion/react';
