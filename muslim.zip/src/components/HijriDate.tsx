import React from 'react';
import { Calendar } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface HijriDateProps {
  language: 'en' | 'ar' | 'ml';
}

export const HijriDate: React.FC<HijriDateProps> = ({ language }) => {
  const today = new Date();
  
  const hijriFormatter = new Intl.DateTimeFormat(
    language === 'ar' ? 'ar-u-ca-islamic-uma' : language === 'ml' ? 'ml-u-ca-islamic-uma' : 'en-u-ca-islamic-uma', 
    { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    }
  );

  const hijriArabicFormatter = new Intl.DateTimeFormat(
    'ar-u-ca-islamic-uma',
    {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }
  );

  const gregorianFormatter = new Intl.DateTimeFormat(
    language === 'ar' ? 'ar' : language === 'ml' ? 'ml' : 'en',
    {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }
  );

  return (
    <Card className="border-primary/10 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 flex items-center gap-4">
        <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center text-secondary">
          <Calendar className="w-6 h-6" />
        </div>
        <div className="flex flex-col">
          <div className="flex flex-col gap-0.5">
            <span className={language === 'ar' ? 'font-arabic text-xl' : language === 'ml' ? 'font-malayalam text-lg' : 'font-serif text-lg font-bold'}>
              {hijriFormatter.format(today)}
            </span>
            {language !== 'ar' && (
              <span className="font-arabic text-sm text-secondary" dir="rtl">
                {hijriArabicFormatter.format(today)}
              </span>
            )}
          </div>
          <span className="text-xs text-muted-foreground mt-1">
            {gregorianFormatter.format(today)}
          </span>
        </div>
      </CardContent>
    </Card>
  );
};
