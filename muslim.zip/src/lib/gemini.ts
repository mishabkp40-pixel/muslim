import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function askFiqh(question: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: question,
      config: {
        systemInstruction: `You are an expert Islamic scholar specializing in Fiqh (Islamic Jurisprudence). 
        Your goal is to provide clear, respectful, and scholarly answers based on the Quran, Sunnah, and the consensus of major Madhahib.
        
        CRITICAL: Provide your answer in THREE languages: Arabic, English, and Malayalam.
        Format the response with:
        1. Arabic Text (Classical scholarly style)
        2. English Translation & Explanation
        3. Malayalam Translation & Explanation
        
        Use clear headings for each language section. Mention if there are differing opinions among the major schools (Hanafi, Maliki, Shafi'i, Hanbali).
        Provide references where possible. Keep the tone humble, wise, and compassionate.
        Format your response using Markdown for readability.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error asking Fiqh:", error);
    return "I apologize, but I am unable to provide an answer at this moment. Please try again later.\n\nأعتذر، لكنني غير قادر على تقديم إجابة في الوقت الحالي.\n\nക്ഷമിക്കണം, ഇപ്പോൾ എനിക്ക് മറുപടി നൽകാൻ സാധിക്കുന്നില്ല.";
  }
}

export async function searchBooks(query: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for famous Islamic Fiqh and scholarly books related to: "${query}". 
      Return a JSON array of objects, each with:
      - 'title' (English)
      - 'titleArabic' (Arabic)
      - 'titleMalayalam' (Malayalam)
      - 'author' (English)
      - 'authorArabic' (Arabic)
      - 'authorMalayalam' (Malayalam)
      - 'century'
      - 'description' (English)
      Focus on authentic and world-renowned works.`,
      config: {
        responseMimeType: "application/json",
      },
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Error searching books:", error);
    return [];
  }
}
