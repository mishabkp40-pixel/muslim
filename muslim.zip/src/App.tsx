/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  BookOpen, 
  Moon, 
  Sun, 
  MessageSquare, 
  ChevronRight, 
  Heart, 
  Scale, 
  Users, 
  Home,
  Info,
  Menu,
  X,
  Send,
  Loader2,
  LogOut,
  User as UserIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { askFiqh, searchBooks } from '@/src/lib/gemini';
import ReactMarkdown from 'react-markdown';
import { WISDOMS, type Wisdom } from '@/src/data/wisdom';
import { ZakatCalculator } from '@/src/components/ZakatCalculator';
import { HijriDate } from '@/src/components/HijriDate';
import { LoginModal } from '@/src/components/LoginModal';
import { PricingModal } from '@/src/components/PricingModal';
import { useAuth } from '@/src/components/AuthProvider';
import { auth } from '@/src/lib/firebase';
import { signOut } from 'firebase/auth';
import { cn } from '@/src/lib/utils';

interface Book {
  title: string;
  titleArabic: string;
  titleMalayalam: string;
  author: string;
  authorArabic: string;
  authorMalayalam: string;
  century: string;
  description: string;
}

const CATEGORIES = [
  {
    title: "Ibadat (Worship)",
    titleArabic: "العبادات",
    titleMalayalam: "ഇബാദത്ത് (ആരാധനകൾ)",
    icon: <Moon className="w-6 h-6" />,
    description: "Rules regarding prayer, fasting, zakat, and pilgrimage.",
    subcategories: [
      { name: "Salah (Prayer)", malayalam: "നിസ്കാരം (സ്വലാത്ത്)" },
      { name: "Sawm (Fasting)", malayalam: "നോമ്പ് (സൗം)" },
      { name: "Zakat (Almsgiving)", malayalam: "സകാത്ത്" },
      { name: "Hajj (Pilgrimage)", malayalam: "ഹജ്ജ്" },
      { name: "Taharah (Purification)", malayalam: "ശുദ്ധി (ത്വഹാറത്ത്)" }
    ]
  },
  {
    title: "Muamalat (Transactions)",
    titleArabic: "المعاملات",
    titleMalayalam: "മുആമലത്ത് (ഇടപാടുകൾ)",
    icon: <Scale className="w-6 h-6" />,
    description: "Islamic commercial law, contracts, and financial ethics.",
    subcategories: [
      { name: "Trade & Commerce", malayalam: "കച്ചവടം" },
      { name: "Banking & Finance", malayalam: "ബാങ്കിംഗ് & ഫിനാൻസ്" },
      { name: "Inheritance", malayalam: "അനന്തരാവകാശം" },
      { name: "Waqf (Endowments)", malayalam: "വഖഫ്" }
    ]
  },
  {
    title: "Munakahat (Family Law)",
    titleArabic: "المناكحات",
    titleMalayalam: "മുനകഹാത്ത് (കുടുംബ നിയമങ്ങൾ)",
    icon: <Heart className="w-6 h-6" />,
    description: "Marriage, divorce, and family responsibilities.",
    subcategories: [
      { name: "Marriage (Nikah)", malayalam: "വിവാഹം (നികാഹ്)" },
      { name: "Divorce (Talaq)", malayalam: "വിവാഹമോചനം (ത്വലാഖ്)" },
      { name: "Parenting", malayalam: "രക്ഷാകർതൃത്വം" },
      { name: "Rights of Spouses", malayalam: "ദമ്പതികളുടെ അവകാശങ്ങൾ" }
    ]
  },
  {
    title: "Jinayat (Criminal Law)",
    titleArabic: "الجنايات",
    titleMalayalam: "ജിനായാത്ത് (ശിക്ഷാ നിയമങ്ങൾ)",
    icon: <Users className="w-6 h-6" />,
    description: "Justice, penalties, and public safety in Islamic law.",
    subcategories: [
      { name: "Public Justice", malayalam: "പൊതു നീതി" },
      { name: "Rights of the Accused", malayalam: "പ്രതിയുടെ അവകാശങ്ങൾ" },
      { name: "Restorative Justice", malayalam: "പുനഃസ്ഥാപന നീതി" }
    ]
  }
];

export default function App() {
  const { user, profile, loading: authLoading } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [chatResponse, setChatResponse] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<Book[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isAskModalOpen, setIsAskModalOpen] = useState(false);
  const [isPricingModalOpen, setIsPricingModalOpen] = useState(false);
  const [chatCount, setChatCount] = useState(0);
  const [currentWisdom, setCurrentWisdom] = useState<Wisdom>(WISDOMS[0]);
  const [appLanguage, setAppLanguage] = useState<'en' | 'ar' | 'ml'>('en');
  const [activeContext, setActiveContext] = useState<{
    type: 'subcategory' | 'wisdom' | 'all_categories' | 'resource' | 'none';
    data?: any;
  }>({ type: 'none' });

  useEffect(() => {
    // Calculate wisdom based on date
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    
    const index = dayOfYear % WISDOMS.length;
    setCurrentWisdom(WISDOMS[index]);
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');
    const upgrade = urlParams.get('upgrade');

    if (sessionId && upgrade === 'success') {
      const verifySession = async () => {
        try {
          const response = await fetch(`/api/verify-session?session_id=${sessionId}`);
          const data = await response.json();
          if (data.status === 'success') {
            alert(appLanguage === 'ar' ? 'تمت الترقية بنجاح!' : appLanguage === 'ml' ? 'അപ്‌ഗ്രേഡ് വിജയിച്ചു!' : 'Upgrade successful!');
            // Clear URL params
            window.history.replaceState({}, document.title, "/");
          }
        } catch (error) {
          console.error('Verification error:', error);
        }
      };
      verifySession();
    }
  }, [appLanguage]);

  useEffect(() => {
    if (activeContext.type === 'none') return;

    let prompt = "";
    if (activeContext.type === 'wisdom') {
      if (appLanguage === 'ar') {
        prompt = `يرجى تقديم شرح فقهي مفصل للحديث: '${currentWisdom.arabic}'`;
      } else if (appLanguage === 'ml') {
        prompt = `'${currentWisdom.malayalam}' എന്ന ഹദീസിനെക്കുറിച്ച് വിശദമായ കർമ്മശാസ്ത്ര വ്യാഖ്യാനം നൽകുക.`;
      } else {
        prompt = `Please provide a detailed scholarly commentary (Sharh) on the Hadith: '${currentWisdom.text}'`;
      }
    } else if (activeContext.type === 'subcategory') {
      const { subcategory, category, malayalamSub } = activeContext.data;
      if (appLanguage === 'ar') {
        prompt = `أود معرفة المزيد عن الأحكام الفقهية المتعلقة بـ '${subcategory}' في قسم '${category}'.`;
      } else if (appLanguage === 'ml') {
        prompt = `'${category}' എന്ന വിഭാഗത്തിലെ '${malayalamSub || subcategory}' എന്ന വിഷയത്തെക്കുറിച്ചുള്ള കർമ്മശാസ്ത്ര വിധികൾ അറിയാൻ ഞാൻ ആഗ്രഹിക്കുന്നു.`;
      } else {
        prompt = `I would like to learn more about the Fiqh rulings regarding '${subcategory}' in the category of '${category}'.`;
      }
    } else if (activeContext.type === 'all_categories') {
      if (appLanguage === 'ar') {
        prompt = "أود رؤية قائمة شاملة لجميع فئات الفقه وأهميتها في الشريعة الإسلامية.";
      } else if (appLanguage === 'ml') {
        prompt = "എല്ലാ കർമ്മശാസ്ത്ര വിഭാഗങ്ങളുടെയും ഒരു സമഗ്രമായ പട്ടികയും ഇസ്‌ലാമിക നിയമത്തിൽ അവയുടെ പ്രാധാന്യവും കാണാൻ ഞാൻ ആഗ്രഹിക്കുന്നു.";
      } else {
        prompt = "I would like to see a comprehensive list of all Fiqh categories and their importance in Islamic law.";
      }
    } else if (activeContext.type === 'resource') {
      const { resourceType } = activeContext.data;
      if (resourceType === 'classical') {
        if (appLanguage === 'ar') {
          prompt = "أريد التعرف على نصوص الفقه الكلاسيكية مثل الموطأ والرسالة. هل يمكنك تقديم لمحة عامة عن أهميتها؟";
        } else if (appLanguage === 'ml') {
          prompt = "അൽ-മുവത്വ, അൽ-രിസാല തുടങ്ങിയ ക്ലാസിക്കൽ കർമ്മശാസ്ത്ര ഗ്രന്ഥങ്ങളെക്കുറിച്ച് അറിയാൻ ഞാൻ ആഗ്രഹിക്കുന്നു. അവയുടെ പ്രാധാന്യത്തെക്കുറിച്ച് ഒരു അവലോകനം നൽകാമോ?";
        } else {
          prompt = "I want to learn about classical Fiqh texts like Al-Muwatta and Al-Risala. Can you provide an overview of their significance?";
        }
      } else if (resourceType === 'fatwa') {
        if (appLanguage === 'ar') {
          prompt = "هل يمكنك تقديم معلومات عن الفتاوى المعاصرة المتعلقة بالقضايا الحديثة مثل التمويل الرقمي والأخلاقيات الحيوية؟";
        } else if (appLanguage === 'ml') {
          prompt = "ഡിജിറ്റൽ ഫിനാൻസ്, ബയോ എത്തിക്സ് തുടങ്ങിയ ആധുനിക വിഷയങ്ങളിലെ സമകാലിക ഫത്‌വകളെക്കുറിച്ചുള്ള വിവരങ്ങൾ നൽകാമോ?";
        } else {
          prompt = "Can you provide information on contemporary fatwas regarding modern issues like digital finance and bioethics?";
        }
      } else if (resourceType === 'comparative') {
        if (appLanguage === 'ar') {
          prompt = "أنا مهتم بالفقه المقارن. هل يمكنك شرح الاختلافات الرئيسية بين المذاهب الأربعة الكبرى في مسألة قانونية شائعة؟";
        } else if (appLanguage === 'ml') {
          prompt = "തുലനാത്മക കർമ്മശാസ്ത്രത്തിൽ എനിക്ക് താൽപ്പര്യമുണ്ട്. ഒരു പൊതുവായ നിയമപ്രശ്നത്തിൽ നാല് പ്രധാന മദ്ഹബുകൾ തമ്മിലുള്ള പ്രധാന വ്യത്യാസങ്ങൾ വിശദീകരിക്കാമോ?";
        } else {
          prompt = "I am interested in comparative Fiqh. Can you explain the main differences between the four major Madhahib on a common legal issue?";
        }
      }
    }

    if (prompt) setChatInput(prompt);
  }, [appLanguage, activeContext, currentWisdom]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    const results = await searchBooks(searchQuery);
    setSearchResults(results);
    setIsSearching(false);
    
    // Scroll to results
    const resultsElement = document.getElementById('search-results');
    if (resultsElement) {
      resultsElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleAskScholar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    // Check limits for free users
    if (profile?.subscriptionStatus !== 'pro' && chatCount >= 3) {
      setIsAskModalOpen(false);
      setIsPricingModalOpen(true);
      return;
    }

    setIsChatLoading(true);
    setChatResponse("");
    const response = await askFiqh(chatInput);
    setChatResponse(response || "No response received.");
    setIsChatLoading(false);
    
    if (profile?.subscriptionStatus !== 'pro') {
      setChatCount(prev => prev + 1);
    }
  };

  const handleShareWisdom = async () => {
    const text = `"${currentWisdom.text}" — ${currentWisdom.attribution}\n\nExplore more at Muslim.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Daily Wisdom - Muslim',
          text: text,
          url: window.location.href,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(`${text}\n${window.location.href}`);
        alert('Wisdom copied to clipboard! • تم نسخ الحكمة!');
      } catch (err) {
        console.error('Error copying:', err);
      }
    }
  };

  const handleReadCommentary = () => {
    setActiveContext({ type: 'wisdom' });
    setIsAskModalOpen(true);
  };

  const handleLogout = () => signOut(auth);

  const handleSubcategoryClick = (subcategory: string, category: string, malayalamSub?: string) => {
    setActiveContext({ 
      type: 'subcategory', 
      data: { subcategory, category, malayalamSub } 
    });
    setIsAskModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-islamic-gold/30">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex bg-muted rounded-full p-1 border border-primary/5">
                <Button 
                  variant={appLanguage === 'en' ? 'secondary' : 'ghost'} 
                  size="sm" 
                  onClick={() => setAppLanguage('en')}
                  className="rounded-full h-7 text-[10px] px-3"
                >
                  EN
                </Button>
                <Button 
                  variant={appLanguage === 'ar' ? 'secondary' : 'ghost'} 
                  size="sm" 
                  onClick={() => setAppLanguage('ar')}
                  className="rounded-full h-7 text-[10px] px-3 font-arabic"
                >
                  عربي
                </Button>
                <Button 
                  variant={appLanguage === 'ml' ? 'secondary' : 'ghost'} 
                  size="sm" 
                  onClick={() => setAppLanguage('ml')}
                  className="rounded-full h-7 text-[10px] px-3 font-malayalam"
                >
                  മല
                </Button>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="rounded-full text-primary hover:bg-primary/10"
              >
                {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-secondary shadow-lg">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="flex flex-col leading-none">
                  <span className="text-xl font-serif font-bold tracking-tight text-primary">Muslim</span>
                  <div className="flex gap-2 items-center">
                    <span className="text-[10px] font-arabic text-secondary" dir="rtl">مسلم</span>
                    <span className="text-[10px] font-malayalam text-secondary/70">മുസ്ലിം</span>
                  </div>
                </div>
              </div>
              
              {/* Header Date Display */}
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="hidden lg:flex flex-col items-start pl-4 border-l border-primary/10 ml-2"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-primary">
                    {new Intl.DateTimeFormat(appLanguage === 'ar' ? 'ar-u-ca-islamic-uma' : appLanguage === 'ml' ? 'ml-u-ca-islamic-uma' : 'en-u-ca-islamic-uma', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date())}
                  </span>
                  {appLanguage !== 'ar' && (
                    <span className="text-[10px] font-arabic text-secondary" dir="rtl">
                      {new Intl.DateTimeFormat('ar-u-ca-islamic-uma', { day: 'numeric', month: 'short' }).format(new Date())}
                    </span>
                  )}
                </div>
                <span className="text-[8px] text-muted-foreground uppercase tracking-tighter">
                  {new Intl.DateTimeFormat(appLanguage === 'ar' ? 'ar' : appLanguage === 'ml' ? 'ml' : 'en', { day: 'numeric', month: 'short' }).format(new Date())}
                </span>
              </motion.div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#" className="text-sm font-medium hover:text-secondary transition-colors flex flex-col items-center">
                <span>Home</span>
                <div className="flex gap-1 text-[8px] opacity-60">
                  <span className="font-arabic" dir="rtl">الرئيسية</span>
                  <span className="font-malayalam">പ്രധാന പേജ്</span>
                </div>
              </a>
              <a href="#categories" className="text-sm font-medium hover:text-secondary transition-colors flex flex-col items-center">
                <span>Categories</span>
                <div className="flex gap-1 text-[8px] opacity-60">
                  <span className="font-arabic" dir="rtl">الأقسام</span>
                  <span className="font-malayalam">വിഭാഗങ്ങൾ</span>
                </div>
              </a>
              <a href="#tools" className="text-sm font-medium hover:text-secondary transition-colors flex flex-col items-center">
                <span>Tools</span>
                <div className="flex gap-1 text-[8px] opacity-60">
                  <span className="font-arabic" dir="rtl">الأدوات</span>
                  <span className="font-malayalam">ഉപകരണങ്ങൾ</span>
                </div>
              </a>
              <a href="#resources" className="text-sm font-medium hover:text-secondary transition-colors flex flex-col items-center">
                <span>Resources</span>
                <div className="flex gap-1 text-[8px] opacity-60">
                  <span className="font-arabic" dir="rtl">المصادر</span>
                  <span className="font-malayalam">വിഭവങ്ങൾ</span>
                </div>
              </a>
              
              {user ? (
                <div className="flex items-center gap-3 pl-4 border-l border-primary/10">
                  <div className="flex flex-col items-end">
                    <div className="flex items-center gap-2">
                      {profile?.subscriptionStatus === 'pro' && (
                        <Badge className="bg-secondary text-secondary-foreground text-[8px] h-4 px-1.5 font-bold uppercase tracking-tighter">Pro</Badge>
                      )}
                      <span className="text-xs font-bold text-primary truncate max-w-[100px]">
                        {user.displayName || user.phoneNumber || 'User'}
                      </span>
                    </div>
                    <button 
                      onClick={handleLogout}
                      className="text-[10px] text-secondary hover:underline flex items-center gap-1"
                    >
                      <LogOut className="w-2 h-2" />
                      {appLanguage === 'ar' ? 'خروج' : appLanguage === 'ml' ? 'ലോഗൗട്ട്' : 'Logout'}
                    </button>
                  </div>
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-primary/20" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <UserIcon className="w-4 h-4" />
                    </div>
                  )}
                </div>
              ) : (
                <LoginModal language={appLanguage} />
              )}
              
              {profile?.subscriptionStatus !== 'pro' && (
                <PricingModal 
                  language={appLanguage} 
                  open={isPricingModalOpen} 
                  onOpenChange={setIsPricingModalOpen} 
                />
              )}
              <Dialog open={isAskModalOpen} onOpenChange={(open) => {
                setIsAskModalOpen(open);
                if (!open) {
                  setChatInput("");
                  setChatResponse("");
                  setActiveContext({ type: 'none' });
                }
              }}>
                <DialogTrigger render={<Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-6 flex items-center gap-2" />}>
                  <span>Ask a Scholar</span>
                  <span className="text-xs font-arabic border-l border-primary-foreground/20 pl-2" dir="rtl">اسأل عالمًا</span>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px] bg-background border-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-serif text-primary flex flex-col gap-1">
                      <div className="flex justify-between items-center">
                        <span>Ask a Fiqh Question</span>
                        <span className="font-arabic text-xl" dir="rtl">اسأل عن مسألة فقهية</span>
                      </div>
                      <span className="font-malayalam text-sm text-secondary/70">കർമ്മശാസ്ത്രപരമായ സംശയങ്ങൾ ചോദിക്കുക</span>
                    </DialogTitle>
                    <div className="flex gap-2 mt-4">
                      <Button 
                        variant={appLanguage === 'en' ? 'secondary' : 'outline'} 
                        size="sm" 
                        onClick={() => setAppLanguage('en')}
                        className="rounded-full text-[10px]"
                      >
                        English
                      </Button>
                      <Button 
                        variant={appLanguage === 'ar' ? 'secondary' : 'outline'} 
                        size="sm" 
                        onClick={() => setAppLanguage('ar')}
                        className="rounded-full text-[10px] font-arabic"
                      >
                        العربية
                      </Button>
                      <Button 
                        variant={appLanguage === 'ml' ? 'secondary' : 'outline'} 
                        size="sm" 
                        onClick={() => setAppLanguage('ml')}
                        className="rounded-full text-[10px] font-malayalam"
                      >
                        മലയാളം
                      </Button>
                    </div>
                  </DialogHeader>
                  <div className="mt-4">
                    <form onSubmit={handleAskScholar} className="flex gap-2 mb-4">
                      <Input 
                        placeholder={
                          appLanguage === 'ar' ? "اكتب سؤالك هنا..." :
                          appLanguage === 'ml' ? "നിങ്ങളുടെ ചോദ്യം ഇവിടെ ടൈപ്പ് ചെയ്യുക..." :
                          "Type your question here..."
                        }
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        className="bg-card border-primary/20 focus-visible:ring-secondary"
                      />
                      <Button type="submit" disabled={isChatLoading} className="bg-primary hover:bg-primary/90">
                        {isChatLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                      </Button>
                    </form>
                    <ScrollArea className="h-[400px] rounded-md border border-primary/10 p-4 bg-card/50">
                      {chatResponse ? (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="prose prose-emerald dark:prose-invert max-w-none"
                        >
                          <ReactMarkdown>{chatResponse}</ReactMarkdown>
                        </motion.div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-muted-foreground italic gap-2">
                          {isChatLoading ? (
                            <>
                              <Loader2 className="w-8 h-8 animate-spin text-secondary" />
                              <span>
                                {appLanguage === 'ar' ? "جاري البحث في المصادر..." :
                                 appLanguage === 'ml' ? "വിവരങ്ങൾ ശേഖരിക്കുന്നു..." :
                                 "Consulting sources..."}
                              </span>
                            </>
                          ) : (
                            <>
                              <span>
                                {appLanguage === 'ar' ? "ستظهر إجابتك هنا." :
                                 appLanguage === 'ml' ? "നിങ്ങളുടെ മറുപടി ഇവിടെ ലഭിക്കും." :
                                 "Your answer will appear here."}
                              </span>
                            </>
                          )}
                        </div>
                      )}
                    </ScrollArea>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
              <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-islamic-cream border-b border-islamic-emerald/10 overflow-hidden"
            >
              <div className="px-4 py-6 space-y-4">
                <a href="#" className="block text-lg font-medium">Home</a>
                <a href="#categories" className="block text-lg font-medium">Categories</a>
                <a href="#tools" className="block text-lg font-medium">Tools</a>
                <a href="#resources" className="block text-lg font-medium">Resources</a>
                <a href="#about" className="block text-lg font-medium">About</a>
                
                {user ? (
                  <div className="pt-4 border-t border-primary/10">
                    <div className="flex items-center gap-3 mb-4">
                      {user.photoURL ? (
                        <img src={user.photoURL} alt="Profile" className="w-10 h-10 rounded-full border border-primary/20" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                          <UserIcon className="w-6 h-6" />
                        </div>
                      )}
                      <div className="flex flex-col">
                        <span className="font-bold text-primary">
                          {user.displayName || user.phoneNumber || 'User'}
                        </span>
                        <span className="text-xs text-muted-foreground">{user.email || user.phoneNumber}</span>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full border-secondary text-secondary hover:bg-secondary/5"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      {appLanguage === 'ar' ? 'تسجيل الخروج' : appLanguage === 'ml' ? 'ലോഗൗട്ട് ചെയ്യുക' : 'Logout'}
                    </Button>
                  </div>
                ) : (
                  <div className="pt-4 border-t border-primary/10">
                    <LoginModal language={appLanguage} />
                  </div>
                )}
                
                <Button 
                  onClick={() => setIsAskModalOpen(true)}
                  className="w-full bg-islamic-emerald text-islamic-cream"
                >
                  Ask a Scholar
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden islamic-pattern">
          <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/70 to-background/90 z-0"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <Badge variant="outline" className="mb-4 border-secondary text-secondary px-4 py-1 rounded-full uppercase tracking-widest text-[10px] font-bold bg-secondary/5">
                  Knowledge is Light • العلم نور
                </Badge>
              </motion.div>
              
              <h1 className="text-5xl md:text-7xl font-serif font-bold text-primary mb-6 leading-tight">
                <motion.span
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2, duration: 0.6 }}
                  className="block"
                >
                  Deepen Your Understanding
                </motion.span>
                <motion.span
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4, duration: 0.6 }}
                  className="italic text-secondary block"
                >
                  of Islamic Jurisprudence
                </motion.span>
              </h1>
              <div className="flex flex-col gap-2 mb-8">
                <div className="font-arabic text-2xl text-primary/80" dir="rtl">
                  تعمق في فهمك للفقه الإسلامي
                </div>
                <div className="font-malayalam text-xl text-secondary/80">
                  ഇസ്‌ലാമിക കർമ്മശാസ്ത്രത്തെക്കുറിച്ചുള്ള നിങ്ങളുടെ അറിവ് വർദ്ധിപ്പിക്കുക
                </div>
              </div>
              <p className="max-w-2xl mx-auto text-lg text-muted-foreground mb-10 font-medium">
                A scholarly resource dedicated to the study of Fiqh, providing authentic guidance for the modern Muslim life.
              </p>
              
              <div className="max-w-xl mx-auto relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-secondary to-primary rounded-full blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <form onSubmit={handleSearch} className="relative flex items-center bg-card rounded-full shadow-xl p-1">
                  <Search className="ml-4 text-muted-foreground w-5 h-5" />
                  <Input 
                    placeholder={
                      appLanguage === 'ar' ? "ابحث عن الأحكام أو المواضيع..." :
                      appLanguage === 'ml' ? "വിധികൾ അല്ലെങ്കിൽ വിഷയങ്ങൾക്കായി തിരയുക..." :
                      "Search for rulings, topics, or madhahib..."
                    }
                    className="border-none focus-visible:ring-0 text-lg bg-transparent"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Button type="submit" disabled={isSearching} className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 h-12">
                    {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                      appLanguage === 'ar' ? "بحث" :
                      appLanguage === 'ml' ? "തിരയുക" :
                      "Search"
                    )}
                  </Button>
                </form>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Search Results Section */}
        <AnimatePresence>
          {searchResults.length > 0 && (
            <motion.section 
              id="search-results"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="py-16 bg-background border-b border-primary/5"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                  <div className="flex flex-col">
                    <h2 className="text-3xl font-serif font-bold text-primary">Search Results: Books & Works</h2>
                    <span className="font-arabic text-secondary" dir="rtl">نتائج البحث: الكتب والمؤلفات</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setSearchResults([])} className="text-muted-foreground hover:text-primary">
                    Clear Results • مسح النتائج
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {searchResults.map((book, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      whileHover={{ y: -5 }}
                      transition={{ delay: idx * 0.05, duration: 0.4 }}
                    >
                      <Card className="h-full border-secondary/20 hover:border-secondary transition-all duration-300 bg-muted/30 hover:shadow-lg">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <Badge className="bg-secondary/20 text-secondary border-none text-[10px] mb-2">
                              {book.century}
                            </Badge>
                          </div>
                          <CardTitle className="text-lg font-serif text-primary flex flex-col gap-1">
                            <span>{book.title}</span>
                            <div className="flex justify-between items-center opacity-70">
                              <span className="font-arabic text-base" dir="rtl">{book.titleArabic}</span>
                              <span className="font-malayalam text-sm">{book.titleMalayalam}</span>
                            </div>
                          </CardTitle>
                          <CardDescription className="text-xs font-bold text-secondary uppercase tracking-wider flex flex-col gap-1">
                            <div className="flex justify-between items-center">
                              <span>By {book.author}</span>
                              <span className="font-arabic normal-case" dir="rtl">{book.authorArabic}</span>
                            </div>
                            <span className="font-malayalam normal-case text-[10px] opacity-60 text-right">{book.authorMalayalam}</span>
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {book.description}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Categories Section */}
        <section id="categories" className="py-24 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
              <div className="max-w-xl">
                <h2 className="text-4xl font-serif font-bold text-primary mb-2">Explore Fiqh Categories</h2>
                <div className="flex flex-col gap-1 mb-4">
                  <div className="font-arabic text-xl text-secondary" dir="rtl">استكشف أقسام الفقه</div>
                  <div className="font-malayalam text-lg text-secondary/70">കർമ്മശാസ്ത്ര വിഭാഗങ്ങൾ പരിശോധിക്കുക</div>
                </div>
                <p className="text-muted-foreground">Comprehensive modules covering every aspect of daily life, from spiritual practice to social ethics.</p>
              </div>
              <Button 
                variant="link" 
                onClick={() => {
                  setActiveContext({ type: 'all_categories' });
                  const askButton = document.querySelector('[data-ask-trigger]') as HTMLButtonElement;
                  if (askButton) askButton.click();
                }}
                className="text-secondary font-bold group"
              >
                View All Categories • عرض جميع الأقسام <ChevronRight className="ml-1 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {CATEGORIES.map((cat, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  whileInView={{ opacity: 1, scale: 1, y: 0 }}
                  whileHover={{ y: -5 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: idx * 0.1, duration: 0.5 }}
                >
                  <Card className="h-full border-primary/5 hover:border-secondary/50 transition-all duration-500 hover:shadow-2xl group bg-card relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/5 rounded-full -mr-12 -mt-12 transition-transform group-hover:scale-150 duration-700"></div>
                    <CardHeader>
                      <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-primary mb-4 group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
                        {cat.icon}
                      </div>
                      <CardTitle className="text-xl font-serif flex flex-col gap-1">
                        <span>{cat.title}</span>
                        <div className="flex justify-between items-center opacity-70">
                          <span className="font-arabic text-lg" dir="rtl">{cat.titleArabic}</span>
                          <span className="font-malayalam text-sm">{cat.titleMalayalam}</span>
                        </div>
                      </CardTitle>
                      <CardDescription className="text-sm leading-relaxed">{cat.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {cat.subcategories.map((sub, sIdx) => (
                          <div 
                            key={sIdx} 
                            onClick={() => handleSubcategoryClick(sub.name, cat.title, sub.malayalam)}
                            className="flex flex-col gap-0.5 hover:text-secondary cursor-pointer transition-colors group/item"
                          >
                            <div className="flex items-center text-xs font-medium text-muted-foreground group-hover/item:text-secondary">
                              <ChevronRight className="w-3 h-3 mr-1 opacity-50" />
                              {sub.name}
                            </div>
                            <div className="font-malayalam text-[10px] pl-4 opacity-60 group-hover/item:opacity-100">
                              {sub.malayalam}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Islamic Tools Section */}
        <section id="tools" className="py-24 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-12">
              <div className="max-w-2xl">
                <Badge variant="outline" className="mb-4 border-secondary text-secondary px-4 py-1 rounded-full uppercase tracking-widest text-[10px] font-bold">
                  Practical Utility • أدوات عملية
                </Badge>
                <h2 className="text-4xl font-serif font-bold text-primary mb-2">
                  {appLanguage === 'ar' ? 'الأدوات الإسلامية' : appLanguage === 'ml' ? 'ഇസ്‌ലാമിക ഉപകരണങ്ങൾ' : 'Islamic Tools & Utilities'}
                </h2>
                <p className="text-muted-foreground">
                  {appLanguage === 'ar' ? 'أدوات عملية لمساعدتك في ممارسة حياتك اليومية كمسلم.' : 
                   appLanguage === 'ml' ? 'ഒരു മുസ്ലീം എന്ന നിലയിൽ നിങ്ങളുടെ ദൈനംദിന ജീവിതത്തിൽ സഹായിക്കുന്നതിനുള്ള പ്രായോഗിക ഉപകരണങ്ങൾ.' : 
                   'Practical tools to assist you in your daily life as a Muslim.'}
                </p>
              </div>
              <div className="w-full md:w-auto">
                <HijriDate language={appLanguage} />
              </div>
            </div>

            <div className="flex justify-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="w-full max-w-md"
              >
                <ZakatCalculator language={appLanguage} />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Daily Wisdom Section */}
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-primary rounded-[2rem] p-8 md:p-16 relative overflow-hidden shadow-2xl"
            >
              <motion.div 
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.1, 0.2, 0.1]
                }}
                transition={{ duration: 8, repeat: Infinity }}
                className="absolute top-0 right-0 w-64 h-64 bg-secondary rounded-full -mr-32 -mt-32 blur-3xl"
              ></motion.div>
              <motion.div 
                animate={{ 
                  scale: [1, 1.3, 1],
                  opacity: [0.1, 0.15, 0.1]
                }}
                transition={{ duration: 10, repeat: Infinity, delay: 1 }}
                className="absolute bottom-0 left-0 w-64 h-64 bg-secondary rounded-full -ml-32 -mb-32 blur-3xl"
              ></motion.div>
              
              <div className="relative z-10 flex flex-col items-center text-center max-w-3xl mx-auto">
                <Badge className="bg-secondary text-secondary-foreground mb-8 px-6 py-1 rounded-full font-bold flex items-center gap-2">
                  <span>Daily Wisdom</span>
                  <div className="flex gap-2 items-center border-l border-secondary-foreground/20 pl-2 text-[10px]">
                    <span className="font-arabic" dir="rtl">حكمة اليوم</span>
                    <span className="font-malayalam">ഇന്നത്തെ വചനം</span>
                  </div>
                </Badge>
                <h3 className="text-3xl md:text-4xl font-serif italic text-primary-foreground mb-4 leading-relaxed">
                  "{currentWisdom.text}"
                </h3>
                <div className="flex flex-col gap-4 mb-8">
                  <div className="font-arabic text-2xl md:text-3xl text-secondary leading-relaxed" dir="rtl">
                    "{currentWisdom.arabic}"
                  </div>
                  <div className="font-malayalam text-xl text-secondary/80 leading-relaxed">
                    "{currentWisdom.malayalam}"
                  </div>
                </div>
                <p className="text-secondary font-medium tracking-widest uppercase text-sm">— {currentWisdom.attribution}</p>
                <div className="mt-12 flex gap-4">
                  <Button 
                    onClick={handleReadCommentary}
                    className="bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold rounded-full px-8 flex items-center gap-2"
                  >
                    <span>Read Commentary</span>
                    <div className="flex gap-2 items-center border-l border-secondary-foreground/20 pl-2 text-[10px]">
                      <span className="font-arabic" dir="rtl">اقرأ التفسير</span>
                      <span className="font-malayalam">വ്യാഖ്യാനം വായിക്കുക</span>
                    </div>
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={handleShareWisdom}
                    className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 rounded-full px-8 flex items-center gap-2"
                  >
                    <span>Share Wisdom</span>
                    <div className="flex gap-2 items-center border-l border-primary-foreground/20 pl-2 text-[10px]">
                      <span className="font-arabic" dir="rtl">شارك الحكمة</span>
                      <span className="font-malayalam">പങ്കുവെക്കുക</span>
                    </div>
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Resources Section */}
        <section id="resources" className="py-24 bg-muted/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-serif font-bold text-primary mb-4">Scholarly Resources</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">Access a curated library of classical texts, fatwas, and contemporary research papers from verified scholars.</p>
            </div>

            <Accordion className="w-full max-w-4xl mx-auto space-y-4">
              <AccordionItem value="item-1" className="bg-card rounded-2xl border border-primary/5 px-6">
                <AccordionTrigger className="text-lg font-serif hover:no-underline">Classical Fiqh Texts</AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  <p className="mb-4">Explore digital versions of Al-Muwatta, Al-Risala, and other foundational texts with modern translations and commentaries.</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setActiveContext({ type: 'resource', data: { resourceType: 'classical' } });
                      const askButton = document.querySelector('[data-ask-trigger]') as HTMLButtonElement;
                      if (askButton) askButton.click();
                    }}
                    className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                  >
                    Learn More • اقرأ المزيد
                  </Button>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2" className="bg-card rounded-2xl border border-primary/5 px-6">
                <AccordionTrigger className="text-lg font-serif hover:no-underline">Contemporary Fatwa Database</AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  <p className="mb-4">A searchable archive of rulings on modern issues like digital finance, bioethics, and social media etiquette.</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setActiveContext({ type: 'resource', data: { resourceType: 'fatwa' } });
                      const askButton = document.querySelector('[data-ask-trigger]') as HTMLButtonElement;
                      if (askButton) askButton.click();
                    }}
                    className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                  >
                    Explore Database • استكشف القاعدة
                  </Button>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3" className="bg-card rounded-2xl border border-primary/5 px-6">
                <AccordionTrigger className="text-lg font-serif hover:no-underline">Comparative Fiqh Studies</AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  <p className="mb-4">Detailed analysis of the differences and similarities between the four major Madhahib on various legal issues.</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setActiveContext({ type: 'resource', data: { resourceType: 'comparative' } });
                      const askButton = document.querySelector('[data-ask-trigger]') as HTMLButtonElement;
                      if (askButton) askButton.click();
                    }}
                    className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                  >
                    View Studies • عرض الدراسات
                  </Button>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground">
                  <BookOpen className="w-5 h-5" />
                </div>
                <span className="text-xl font-serif font-bold tracking-tight">Muslim</span>
              </div>
              <p className="text-primary-foreground/60 max-w-sm leading-relaxed">
                Dedicated to preserving and propagating the authentic knowledge of Islamic Jurisprudence for the global Ummah.
              </p>
            </div>
            <div>
              <h4 className="font-serif font-bold text-lg mb-6">Quick Links</h4>
              <ul className="space-y-4 text-sm text-primary-foreground/60">
                <li><a href="#" className="hover:text-secondary transition-colors">Home</a></li>
                <li><a href="#categories" className="hover:text-secondary transition-colors">Fiqh Categories</a></li>
                <li><a href="#tools" className="hover:text-secondary transition-colors">Islamic Tools</a></li>
                <li><a href="#resources" className="hover:text-secondary transition-colors">Scholarly Resources</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Contact Us</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif font-bold text-lg mb-6">Connect</h4>
              <ul className="space-y-4 text-sm text-primary-foreground/60">
                <li><a href="#" className="hover:text-secondary transition-colors">Newsletter</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Podcast</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Community Forum</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Support Our Work</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-primary-foreground/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-primary-foreground/40">
            <p>© 2024 Muslim. All rights reserved.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-secondary transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-secondary transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
