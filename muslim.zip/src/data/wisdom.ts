export interface Wisdom {
  text: string;
  arabic: string;
  malayalam: string;
  attribution: string;
}

export const WISDOMS: Wisdom[] = [
  {
    text: "The best of you are those who learn the Quran and teach it.",
    arabic: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    malayalam: "നിങ്ങളിൽ ഉത്തമൻ ഖുർആൻ പഠിക്കുകയും അത് മറ്റുള്ളവർക്ക് പഠിപ്പിക്കുകയും ചെയ്യുന്നവനാണ്.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "Seeking knowledge is an obligation upon every Muslim.",
    arabic: "طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ",
    malayalam: "വിദ്യ തേടുക എന്നത് ഓരോ മുസ്ലിമിനും നിർബന്ധമാണ്.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "Allah makes the way to Jannah easy for him who treads the path in search of knowledge.",
    arabic: "مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ",
    malayalam: "അറിവ് തേടി ഒരു വഴിയിലൂടെ സഞ്ചരിക്കുന്നവന് അല്ലാഹു സ്വർഗത്തിലേക്കുള്ള വഴി എളുപ്പമാക്കിക്കൊടുക്കും.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "The most beloved of deeds to Allah are those that are most consistent, even if they are small.",
    arabic: "أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ",
    malayalam: "അല്ലാഹുവിന് ഏറ്റവും പ്രിയപ്പെട്ട കർമ്മങ്ങൾ കുറവാണെങ്കിലും സ്ഥിരമായി ചെയ്യുന്നവയാണ്.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "Verily, actions are by intentions, and every person will have only what they intended.",
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    malayalam: "കർമ്മങ്ങൾ ഉദ്ദേശ്യങ്ങൾക്കനുസരിച്ചാണ്. ഓരോ മനുഷ്യനും അവൻ ഉദ്ദേശിച്ചത് മാത്രമേ ലഭിക്കുകയുള്ളൂ.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "A good word is charity.",
    arabic: "الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ",
    malayalam: "നല്ല വാക്ക് ഒരു ധർമ്മമാണ്.",
    attribution: "Prophet Muhammad (ﷺ)"
  },
  {
    text: "None of you truly believes until he loves for his brother what he loves for himself.",
    arabic: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ",
    malayalam: "തനിക്ക് ഇഷ്ടപ്പെടുന്നത് തന്റെ സഹോദരനും ഇഷ്ടപ്പെടുന്നത് വരെ നിങ്ങളിലാരും പൂർണ്ണ വിശ്വാസിയാവുകയില്ല.",
    attribution: "Prophet Muhammad (ﷺ)"
  }
];
